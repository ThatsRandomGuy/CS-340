from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):

	#Setting default values
	def __init__(self, username, password):
		USER = 'aacuser'
		PASS = 'Pluto!'
		HOST = 'nv-desktop-services.apporto.com'
		PORT = 31743
		DB = 'AAC'
		COL = 'animals'

		self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
		self.database = self.client['%s' % (DB)]
		self.collection = self.database['%s' % (COL)]

	#Creating create method
	def create(self, data):
		#Verifying create data variable is not empty
		if data is not None:
			insert = self.database.animals.insert(data)
			#Verifying successful insertion
			if insert != 0:
				return True
			return False
		else:
			raise Exception("There is no data to insert")

	#Creating read method
	def read(self, criteria):
		#Verifying read data variable is not empty
		if criteria:
			data = self.database.animals.find(criteria, {"_id": False})
			for document in data:
				returnData = "".join(str(document))
				return returnData
		else:
			data = self.database.animals.find({}, {"_id": False})
			return list(data)
	
		
	#Creating update method
	def update(self, updateData):
		#Verifying updateData variable is not empty
		if updateData is not None:
			if updateData:
				result = self.database.animal.insert_one(updateData)
			return result
		else:
			raise Exception("There is nothing to update")
			
	#Creating delete method
	def delete(self, deleteData):
		#Verifying deleteData variable is not empty
		if deleteData is not None:
			if deleteData:
				result = self.database.animals.delete_one(deleteData)
		else:
			raise Exception("There is nothing to remove")
